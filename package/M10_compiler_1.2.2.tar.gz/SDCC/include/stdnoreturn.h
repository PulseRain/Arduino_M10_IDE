#ifndef __SDCC_STDNORETURN_H
#define __SDCC_STDNORETURN_H 1

#define noreturn _Noreturn

#endif


#include "Arduino.h"



void main()
{           
    Serial.begin(115200);
    ET1 = 1;
    EA = 1;
    delay (1000);
    delay (1000);
    
    setup();
    
    while (1) {
      loop();
    }
    
    
}  

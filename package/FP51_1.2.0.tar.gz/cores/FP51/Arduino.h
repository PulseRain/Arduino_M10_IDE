/*
###############################################################################
# Copyright (c) 2016, PulseRain Technology LLC 
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License (LGPL) as 
# published by the Free Software Foundation, either version 3 of the License,
# or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
# or FITNESS FOR A PARTICULAR PURPOSE.  
# See the GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################
*/

#ifndef _ARDUINO_H
#define _ARDUINO_H

#include "8051.h"

#include "debug.h"
#include "common_type.h"
#include "peripherals.h"


#define INPUT  0
#define OUTPUT 1

#define HIGH 1
#define LOW 0

#define DEC 0
#define BIN 1
#define OCT 2
#define HEX 3

#ifndef false
#define false 0
#endif

#ifndef true
#define true 1
#endif

#define INPUT  0
#define OUTPUT 1

#define HIGH 1
#define LOW 0


typedef struct {
   void (*begin) (uint32_t); 
   uint8_t (*available)();
   void (*print) (int32_t num, uint8_t fmt) __reentrant;
   void (*printHex) (uint32_t num);
   void (*println) (int32_t data, uint8_t fmt) __reentrant;
   void (*writeByte) (uint8_t data);
   
   uint8_t   (*read)();
   uint8_t   (*readBytes) (uint8_t* buf, uint16_t length) __reentrant;
   
   void (*write) (uint8_t* buf, uint16_t length) __reentrant;
   void (*setTimeout)(uint32_t time_out_in_ms);
   uint8_t readLn(uint8_t* buf, uint16_t max_length) __reentrant;
   void (*end)();   
   
} SERIAL_STRUCT;


extern void serial_begin (uint32_t rate);
extern void serial_print_dec_S32 (int32_t num);
extern void serial_print_hex (uint32_t num);
extern void serial_printLn(int32_t data, uint8_t fmt) __reentrant;
extern void serial_putchar (uint8_t c);
extern uint8_t serial_receive ();
extern uint8_t serial_readBytes_reentrant(uint8_t* buf, uint16_t length) __reentrant;
extern void serial_write_reentrant (uint8_t* buf, uint16_t length) __reentrant;
extern void serial_set_timeout(uint32_t time_out_in_ms);
extern uint8_t serial_readLine_reentrant(uint8_t* buf, uint16_t max_length) __reentrant;
extern void serial_end ();
extern void serial_print_oct (uint32_t num);
extern void serial_print_int (int32_t num, uint8_t fmt) __reentrant;


extern const SERIAL_STRUCT Serial;

extern void delay (uint32_t delay_in_ms);

extern void jtag_putchar (uint8_t char_in);


extern void setup(void);
extern void loop(void);


#endif
